package com.wolkabout.exam.api.dto;

import java.time.LocalDateTime;
import java.util.StringJoiner;

public class TaskUpdateDetails {

    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private String description;

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalDateTime endTime) {
        this.endTime = endTime;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    @Override
    public String toString() {
        return new StringJoiner(", ", TaskUpdateDetails.class.getSimpleName() + "[", "]")
                .add("startTime=" + startTime)
                .add("endTime=" + endTime)
                .add("description='" + description + "'")
                .toString();
    }

}
