package com.wolkabout.exam.api;

import com.wolkabout.exam.BaseTest;
import com.wolkabout.exam.api.dto.TaskCreationDetails;
import com.wolkabout.exam.api.dto.TaskUpdateDetails;
import com.wolkabout.exam.model.Task;
import com.wolkabout.exam.model.User;
import com.wolkabout.exam.repository.TaskRepository;
import com.wolkabout.exam.repository.UserRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.time.LocalDateTime;
import java.util.stream.IntStream;

import static org.hamcrest.Matchers.hasSize;

public class TaskApiTest extends BaseTest {

    private final TaskRepository taskRepository;
    private final UserRepository userRepository;

    @Autowired
    public TaskApiTest(TaskRepository taskRepository, UserRepository userRepository) {
        this.taskRepository = taskRepository;
        this.userRepository = userRepository;
    }

    @Test
    public void createTaskTest() throws Exception {
        User user = new User();
        user.setEmail("testuser@wolkabout.com");
        user.setPassword("password");
        userRepository.save(user);

        TaskCreationDetails taskDetails = new TaskCreationDetails();
        taskDetails.setStartTime(LocalDateTime.now());
        taskDetails.setEndTime(LocalDateTime.now().plusHours(1));
        taskDetails.setDescription("Test Task");
        taskDetails.setUserId(user.getId());

        mockMvc.perform(MockMvcRequestBuilders.post("/api/users/" + user.getId() + "/tasks")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(toJson(taskDetails)))
                .andExpect(MockMvcResultMatchers.status().isCreated())
                .andExpect(MockMvcResultMatchers.jsonPath("$.id").isNotEmpty())
                .andExpect(MockMvcResultMatchers.jsonPath("$.description").value(taskDetails.getDescription()))
                .andExpect(MockMvcResultMatchers.jsonPath("$.user.id").value(user.getId()));
    }


    @Test
    public void listTasksTest() throws Exception {
        User user = new User();
        user.setEmail("testuser@wolkabout.com");
        user.setPassword("password");
        userRepository.save(user);

        IntStream.range(0, 10).forEach(i -> {
            Task task = new Task();
            task.setStartTime(LocalDateTime.now());
            task.setEndTime(LocalDateTime.now().plusHours(1));
            task.setDescription("Task " + i);
            task.setUser(user);
            taskRepository.save(task);
        });

        mockMvc.perform(MockMvcRequestBuilders.get("/api/users/" + user.getId() + "/tasks"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$", hasSize(10)));
    }

    @Test
    public void getTaskTest() throws Exception {
        User user = new User();
        user.setEmail("testuser@wolkabout.com");
        user.setPassword("password");
        userRepository.save(user);

        Task task = new Task();
        task.setStartTime(LocalDateTime.now());
        task.setEndTime(LocalDateTime.now().plusHours(1));
        task.setDescription("Test Task");
        task.setUser(user);
        taskRepository.save(task);

        mockMvc.perform(MockMvcRequestBuilders.get("/api/tasks/" + task.getId()))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.id").value(task.getId()))
                .andExpect(MockMvcResultMatchers.jsonPath("$.description").value(task.getDescription()));
    }

        @Test
        public void updateTaskTest() throws Exception {
            User user = new User();
            user.setEmail("testuser@wolkabout.com");
            user.setPassword("password");
            userRepository.save(user);

            Task task = new Task();
            task.setStartTime(LocalDateTime.now());
            task.setEndTime(LocalDateTime.now().plusHours(1));
            task.setDescription("Test Task");
            task.setUser(user);
            taskRepository.save(task);

            TaskUpdateDetails updateDetails = new TaskUpdateDetails();
            updateDetails.setStartTime(LocalDateTime.now().plusHours(1));
            updateDetails.setEndTime(LocalDateTime.now().plusHours(2));
            updateDetails.setDescription("Updated Task");

            mockMvc.perform(MockMvcRequestBuilders.put("/api/tasks/" + task.getId())
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(toJson(updateDetails)))
                    .andExpect(MockMvcResultMatchers.status().isOk())
                    .andExpect(MockMvcResultMatchers.jsonPath("$.id").value(task.getId()))
                    .andExpect(MockMvcResultMatchers.jsonPath("$.description").value(updateDetails.getDescription()));
        }

    @Test
    public void deleteTaskTest() throws Exception {
        User user = new User();
        user.setEmail("testuser@wolkabout.com");
        user.setPassword("password");
        userRepository.save(user);

        Task task = new Task();
        task.setStartTime(LocalDateTime.now());
        task.setEndTime(LocalDateTime.now().plusHours(1));
        task.setDescription("Test Task");
        task.setUser(user);
        taskRepository.save(task);

        mockMvc.perform(MockMvcRequestBuilders.delete("/api/tasks/" + task.getId()))
                .andExpect(MockMvcResultMatchers.status().isNoContent());
    }
}