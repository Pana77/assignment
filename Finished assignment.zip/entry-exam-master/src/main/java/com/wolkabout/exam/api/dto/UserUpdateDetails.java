package com.wolkabout.exam.api.dto;

import java.util.StringJoiner;

public class UserUpdateDetails {

    private String password;

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", UserUpdateDetails.class.getSimpleName() + "[", "]")
                .add("password='" + getPassword() + "'")
                .toString();
    }
}
