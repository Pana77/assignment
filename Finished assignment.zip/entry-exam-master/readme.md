WolkAbout's Technical Assignment
==

Greetings upon you friend.


Before you is a basic Spring Boot application.
The application currently contains "User" as its single entity class. 
A simple CRUD API is implemented to retrieve and manage users.

Your mission, should you choose to accept it:

```
By following the existing project organization, 
add a feature where an API will allow for adding and listing Tasks for users.

Regarding a Task:
    Each task must be assignable to a single user.
    Each task must have a start time, end time, and a text description of the task.

Prove that the software works!
```

GL HF
