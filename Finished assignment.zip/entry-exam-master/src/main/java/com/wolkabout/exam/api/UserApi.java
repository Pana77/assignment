package com.wolkabout.exam.api;

import com.wolkabout.exam.api.dto.TaskCreationDetails;
import com.wolkabout.exam.api.dto.UserCreationDetails;
import com.wolkabout.exam.api.dto.UserUpdateDetails;
import com.wolkabout.exam.model.Task;
import com.wolkabout.exam.repository.TaskRepository;
import com.wolkabout.exam.repository.UserRepository;
import com.wolkabout.exam.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/users")
public class UserApi {

    private final UserRepository userRepository;
    private final TaskRepository taskRepository;

    @Autowired
    public UserApi(UserRepository userRepository, TaskRepository taskRepository) {
        this.userRepository = userRepository;
        this.taskRepository = taskRepository;
    }
    @GetMapping("/{id}")
    public ResponseEntity<User> getUser(@PathVariable long id) {
        return userRepository.findById(id)
                .map(user -> new ResponseEntity<>(user, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @GetMapping
    public ResponseEntity<List<User>> listUsers(@RequestParam String searchParameters) {
        final List<User> users = userRepository.findByEmailContaining(searchParameters);
        return new ResponseEntity<>(users, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<User> createUser(@RequestBody UserCreationDetails details) {
        final User user = new User();
        user.setEmail(details.getEmail());
        user.setPassword(details.getPassword());
        userRepository.save(user);

        return new ResponseEntity<>(user, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<User> updateUser(@PathVariable long id, @RequestBody UserUpdateDetails details) {
        return userRepository.findById(id).map(user -> {
            user.setPassword(details.getPassword());
            userRepository.save(user);
            return new ResponseEntity<>(user, HttpStatus.OK);
        }).orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUser(@PathVariable long id) {
        userRepository.deleteById(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
    // New methods for handling tasks

    @GetMapping("/{userId}/tasks")
    public ResponseEntity<List<Task>> listTasksForUser(@PathVariable long userId) {
        return userRepository.findById(userId).map(user -> {
            List<Task> tasks = taskRepository.findByUserId(userId);
            return new ResponseEntity<>(tasks, HttpStatus.OK);
        }).orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @PostMapping("/{userId}/tasks")
    public ResponseEntity<Task> createTaskForUser(@PathVariable long userId, @RequestBody TaskCreationDetails details) {
        return userRepository.findById(userId).map(user -> {
            Task task = new Task();
            task.setStartTime(details.getStartTime());
            task.setEndTime(details.getEndTime());
            task.setDescription(details.getDescription());
            task.setUser(user);
            taskRepository.save(task);
            return new ResponseEntity<>(task, HttpStatus.CREATED);
        }).orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }
}
