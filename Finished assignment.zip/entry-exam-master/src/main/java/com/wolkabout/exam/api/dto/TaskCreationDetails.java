package com.wolkabout.exam.api.dto;

import java.time.LocalDateTime;
import java.util.StringJoiner;

public class TaskCreationDetails {

    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private String description;
    private Long userId;

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalDateTime endTime) {
        this.endTime = endTime;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", TaskCreationDetails.class.getSimpleName() + "[", "]")
                .add("startTime=" + startTime)
                .add("endTime=" + endTime)
                .add("description='" + description + "'")
                .add("userId=" + userId)
                .toString();
    }
}
